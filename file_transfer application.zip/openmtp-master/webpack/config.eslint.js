/* eslint import/no-unresolved: off, import/no-self-import: off */
require('@babel/register');

module.exports = require('./config.renderer.dev.babel').default;
