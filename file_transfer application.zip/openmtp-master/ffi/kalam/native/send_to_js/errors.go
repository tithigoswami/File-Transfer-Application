package send_to_js

type MtpDetectFailedError struct {
	error
}

type MtpChangedError struct {
	error
}
