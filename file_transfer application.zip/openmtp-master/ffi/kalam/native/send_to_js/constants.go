package send_to_js

const DateTimeFormat = "2006-01-02T15:04:05.000Z"
