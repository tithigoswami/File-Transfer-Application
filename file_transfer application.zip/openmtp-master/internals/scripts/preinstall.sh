#!/bin/zsh

node ./internals/scripts/CheckYarn.js
