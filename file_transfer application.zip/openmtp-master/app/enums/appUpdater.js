export const UPDATER_STATUS = {
  inactive: 'inactive',
  checkInProgress: 'checkInProgress',
  updateInProgress: 'updateInProgress',
};
