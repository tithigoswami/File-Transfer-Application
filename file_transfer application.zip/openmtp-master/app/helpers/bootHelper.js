import Boot from '../classes/Boot';

export const bootLoader = new Boot();
