export const helpPhoneNotConnecting = `FAQs - My phone is not connecting!`;

export const buyMeACoffeeText = `Buy me a Coffee (UPI, PayPal, Credit/Debit Cards, Internet Banking)`;

export const supportUsingPayPal = `Support us via PayPal`;
