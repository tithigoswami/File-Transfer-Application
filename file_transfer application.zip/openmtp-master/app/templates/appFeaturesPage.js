export const APP_FEATURES_PAGE_TITLE = `New Features and Updates`;
