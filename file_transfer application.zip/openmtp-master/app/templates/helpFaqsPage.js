export const HELP_PHONE_IS_NOT_CONNECTING = `Help - My Phone is not connecting`;

export const FAQS_PAGE_TITLE = `Help - FAQs`;
