export const PRIVACY_POLICY_PAGE_TITLE = `Privacy Policy`;
