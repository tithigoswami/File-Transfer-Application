export const KEYBOARD_SHORTCUTS_PAGE_TITLE = `Keyboard Shortcuts`;
