// most recently used version number to show the onboarding screen
// search keywords: new, next, update, onboarding
export const latestUpdatePushVersion = '3.2.20';
