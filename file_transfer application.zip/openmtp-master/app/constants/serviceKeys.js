export const SERVICE_KEYS = {
  sentryDsn: `https://1f60d05960cc4c10a744bebd19bc2814@o410539.ingest.sentry.io/5544425`,
  googleAnalytics: `UA-131227413-1`,
  mixpanelAnalytics: `e2ae6803122e622822a5fbf32ff0e5ae`,
};
