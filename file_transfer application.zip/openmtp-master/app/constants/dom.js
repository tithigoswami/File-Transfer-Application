export const APP_TITLEBAR_DOM_ID = `app-main-titlebar`;

export const FILE_EXPLORER_BODY_WRAPPER_ID = `file-explorer-body-wrapper`;
