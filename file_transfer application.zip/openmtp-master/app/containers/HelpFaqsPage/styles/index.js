export const styles = (_) => ({
  root: {
    textAlign: `left`,
    padding: '30px 30px 30px 30px',
    maxWidth: 950,
    marginRight: 'auto',
    marginLeft: 'auto',
    overflow: 'auto',
  },
  a: {
    fontWeight: `bold`,
  },
  heading: {},
  body: {
    paddingTop: 25,
  },
});
