export const styles = (_) => ({
  root: {},
  title: {
    fontWeight: `bold`,
  },
  nestedPanel: {
    paddingLeft: 16,
    paddingRight: 16,
  },
});
