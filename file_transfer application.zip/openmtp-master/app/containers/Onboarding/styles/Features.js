export const styles = (_) => ({
  root: {},
  title: {
    fontWeight: `bold`,
  },
});
