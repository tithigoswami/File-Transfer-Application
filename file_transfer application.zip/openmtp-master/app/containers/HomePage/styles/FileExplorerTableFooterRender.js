export const styles = (_) => ({
  tableFooter: {
    display: 'unset !important',
  },
});
