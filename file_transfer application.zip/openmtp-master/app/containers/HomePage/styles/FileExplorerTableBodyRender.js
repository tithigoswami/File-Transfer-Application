export const styles = (_) => ({
  table: {},
});
