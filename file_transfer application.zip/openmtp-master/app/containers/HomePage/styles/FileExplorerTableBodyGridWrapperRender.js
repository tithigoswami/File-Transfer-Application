export const styles = (_) => ({
  wrapper: {},
  gridTableCell: {
    paddingLeft: `5px !important`,
    paddingRight: `5px !important`,
    border: 0,
  },
});
