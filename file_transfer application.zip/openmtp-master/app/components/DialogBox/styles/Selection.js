export const styles = (theme) => ({
  root: {},
  selectedAvatar: {
    background: theme.palette.secondary.main,
  },
  selectedIcon: {
    color: '#fff',
  },
});
