import { isPackaged as _isPackaged } from 'electron-is-packaged';

export const isPackaged = _isPackaged;
