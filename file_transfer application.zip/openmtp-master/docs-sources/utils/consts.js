export const ALLOWED_GITHUB_FETCH_STATUSES = [200, 403, 404];

export const APP_GITHUB_URL = `https://github.com/ganeshrvel/openmtp`;

export const APP_GITHUB_API_URL = `https://api.github.com/repos/ganeshrvel/openmtp/releases/latest`;
